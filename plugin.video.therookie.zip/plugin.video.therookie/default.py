import sys
import urllib.parse
import xbmcplugin
import xbmcgui

base_url = sys.argv[0]
handle = int(sys.argv[1])
args = sys.argv[2]

stream_links = {
    "7": {
        "1": "https://vidsrc.to/embed/tv/tt7587890/7/1",
        "2": "https://vidsrc.to/embed/tv/tt7587890/7/2",
        "3": "https://vidsrc.to/embed/tv/tt7587890/7/3",
        "4": "https://vidsrc.to/embed/tv/tt7587890/7/4",
        "5": "https://vidsrc.to/embed/tv/tt7587890/7/5",
        "6": "https://vidsrc.to/embed/tv/tt7587890/7/6",
        "7": "https://vidsrc.to/embed/tv/tt7587890/7/7",
        "8": "https://vidsrc.to/embed/tv/tt7587890/7/8",
        "9": "https://vidsrc.to/embed/tv/tt7587890/7/9",
        "10": "https://vidsrc.to/embed/tv/tt7587890/7/10",
        "11": "https://vidsrc.to/embed/tv/tt7587890/7/11",
        "12": "https://vidsrc.to/embed/tv/tt7587890/7/12",
        "13": "https://vidsrc.to/embed/tv/tt7587890/7/13",
        "14": "https://vidsrc.to/embed/tv/tt7587890/7/14",
        "15": "https://vidsrc.to/embed/tv/tt7587890/7/15",
        "16": "https://vidsrc.to/embed/tv/tt7587890/7/16",
        "17": "https://vidsrc.to/embed/tv/tt7587890/7/17",
        "18": "https://vidsrc.to/embed/tv/tt7587890/7/18"
    }
}

episode_titles = {
    "1": "Attention! New Recruits!",
    "2": "A Neighborhood Superhero",
    "3": "High Security",
    "4": "The Threat",
    "5": "To the End",
    "6": "The Gala",
    "7": "A Restless Night",
    "8": "The Fire",
    "9": "The Kiss",
    "10": "The Veil of Lies",
    "11": "Race Against the Bomb",
    "12": "April Fools",
    "13": "Bad Publicity",
    "14": "Crime Crazies",
    "15": "A Case Like No Other",
    "16": "The Return",
    "17": "Too Beautiful for Me",
    "18": "The Good, the Bad, and the Oscar"
}

def list_episodes():
    for ep_num in sorted(stream_links["7"].keys(), key=lambda x: int(x)):
        url = build_url({'mode': 'play', 'season': '7', 'episode': ep_num})
        list_item = xbmcgui.ListItem(label=f"S07E{ep_num.zfill(2)} - {episode_titles[ep_num]}")
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

def play_episode(season, episode):
    url = stream_links.get(season, {}).get(episode)
    if not url:
        xbmcgui.Dialog().notification("Error", "Episode URL not found", xbmcgui.NOTIFICATION_ERROR)
        return
    play_item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(handle, True, listitem=play_item)

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

def router(paramstring):
    params = urllib.parse.parse_qs(paramstring)
    mode = params.get('mode', [None])[0]

    if mode is None:
        list_episodes()
    elif mode == 'play':
        season = params.get('season', [None])[0]
        episode = params.get('episode', [None])[0]
        play_episode(season, episode)

if __name__ == '__main__':
    router(args)